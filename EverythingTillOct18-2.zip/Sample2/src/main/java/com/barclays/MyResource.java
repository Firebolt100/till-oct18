package com.barclays;

import javax.ws.rs.Consumes;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Response;

/**
 * Root resource (exposed at "myresource" path)
 */
@Path("myresource")
public class MyResource {
	Person p = new Person();
    /**
     * Method handling HTTP GET requests. The returned object will be sent
     * to the client as "text/plain" media type.
     *
     * @return String that will be returned as a text/plain response.
     */
    @GET
    @Produces(MediaType.TEXT_PLAIN)
    public String getIt() {
        return "Got it!";
    }
    
    @Path("person")
    @GET
    @Produces(value={MediaType.APPLICATION_XML,MediaType.APPLICATION_JSON} )
    public Person getPersonDetails(){
    	
    	Person p = new Person();
    	p.setAge(23);
    	p.setName("Grant");
    	
    	return p;
    }
    
    /*@Path("person2") 
    @POST
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    @Produces(MediaType.TEXT_PLAIN)
    public String setPersonDetails(MultivaluedMap<String, Object> map){
    	System.out.println(map);
    	return Response.status(200).build();
    }*/
    
    @Path("save") 
    @POST
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    @Produces(MediaType.TEXT_HTML)
    public String savePerson(@FormParam("name") String name,@FormParam("age") int age){
    	p.setAge(age);
    	p.setName(name);
    	System.out.println(p.getName() + "\t" + p.getAge());
    	return "added successfully";
    }
}
