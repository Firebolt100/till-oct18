package com.pcp;

public class Container {

	private int size = 0;
	
	
	
	synchronized void put(){
		
		while(size!=0){ // wait for condition : if this condition is true only den move forth
			try {
				
				this.wait();
				
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		this.size=1;
		this.notify();
		//to give time 
		try {
			
			Thread.sleep(1000);
			
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
		System.out.println("1 product produced by producer");
		
		
	}
	
	synchronized void get(){
		
		while(size!=1){
			
			try {
				this.wait();
				
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		
		this.size=0;  // consumer consumed it
		
		this.notify();
		
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
		System.out.println("Consumer consumed 1 product");
		
		
	}
}
