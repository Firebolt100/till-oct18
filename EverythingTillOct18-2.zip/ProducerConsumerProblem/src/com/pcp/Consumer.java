package com.pcp;

public class Consumer extends Thread {

	private Container box;
	
	Consumer(Container box){
		this.box = box;
	}
	
	public void run(){
		
		box.get();
		
	}
}
