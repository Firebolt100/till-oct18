package com.pcp;

public class Entry {
	public static void main(String[] args) {
			
		Container b = new Container();
		
		Producer p1 = new Producer(b);
		Producer p2 = new Producer(b);
		Producer p3 = new Producer(b);
		Producer p4 = new Producer(b);
		
		Consumer c1 = new Consumer(b);
		Consumer c2 = new Consumer(b);
		Consumer c3 = new Consumer(b);
		Consumer c4 = new Consumer(b);
		
		p1.start();
		c1.start();
		
		p2.start();
		c2.start();
		
		p3.start();
		c3.start();
		
		p4.start();
		c4.start();
		
		
	
	
}
}
