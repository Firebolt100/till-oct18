package com.barclays;

import javax.jws.WebService;

@WebService
public interface HelloWorld {
    String sayHi(String text);
}

