@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.pluralsight.com/schema/Order", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.pluralsight.schema.order;
