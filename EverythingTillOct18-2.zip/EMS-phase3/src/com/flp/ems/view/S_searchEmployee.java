package com.flp.ems.view;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.HashMap;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.ems.service.EmployeeServiceImpl;

@WebServlet("/searchEmployee")
public class S_searchEmployee extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String name =null, kinId=null ,emailId=null;
		HashMap<String,String> search = new HashMap<String,String>(); 
		EmployeeServiceImpl empService = new EmployeeServiceImpl();
		PrintWriter out = response.getWriter();
		
		if(request.getParameter("kinId")!=null){
			kinId = request.getParameter("kinId");
			search.put("kinId", kinId);
			System.out.println("in VIEW layer "+ kinId);
		}
		
		if(request.getParameter("name")!=null){
			name = request.getParameter("name");
			search.put("name", name);
		}
		
		if(request.getParameter("emailId")!=null){
			emailId = request.getParameter("emailId");
			search.put("emailId", emailId);
		}
		
		HashMap<String , String> hashMap=null;
		try {
			hashMap= empService.SearchEmployee(search);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		out.println("<html><body>");
		out.println("<h2>The Employee Searched for  <h2><br>");
		out.println("<p>"+hashMap.get("kinId")+" : "+hashMap.get("name")+" : "+hashMap.get("emailId")+" : "+hashMap.get("phoneNo")+" : "+hashMap.get("deptId")+" : "+hashMap.get("projectId")+" : "+hashMap.get("roleId") + "<p>");
		out.println("</body></html>");	
	}

}
