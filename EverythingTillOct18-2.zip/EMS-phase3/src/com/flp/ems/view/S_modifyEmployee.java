package com.flp.ems.view;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.HashMap;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.ems.service.EmployeeServiceImpl;

@WebServlet("/modifyEmployee")
public class S_modifyEmployee extends HttpServlet {
	private static final long serialVersionUID = 1L;
 
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		EmployeeServiceImpl empService = new EmployeeServiceImpl();   
		PrintWriter out = response.getWriter();
		
		RequestDispatcher rd=request.getRequestDispatcher("getAllEmployees");
		rd.include(request, response);
		
	/*	RequestDispatcher rd2=request.getRequestDispatcher("getKinId.html");
		rd2.include(request, response);
		
		String kinId = request.getParameter("kinId");
		request.setAttribute("kinId", kinId);*/
		
		RequestDispatcher rd3=request.getRequestDispatcher("modifyEmployee.html");
		rd3.include(request, response);
		
		HashMap<String,String> m = new HashMap<String,String>();
		
		m.put("kinId", request.getParameter("kinId"));
		
		if(request.getParameter("name")!=null){
			m.put("name", request.getParameter("name"));
		}
		if(request.getParameter("phoneNo")!=null){
			m.put("phoneNo", request.getParameter("phoneNo"));
		}
		if(request.getParameter("address")!=null){
			m.put("address", request.getParameter("address"));
		}
		if(request.getParameter("dob")!=null){
			m.put("dob", request.getParameter("dob"));
		}
		if(request.getParameter("doj")!=null){
			m.put("doj", request.getParameter("doj"));
		}
		if(request.getParameter("department")!=null){
			m.put("department", request.getParameter("department"));
		}
		if(request.getParameter("project")!=null){
			m.put("project", request.getParameter("project"));
		}
		if(request.getParameter("role")!=null){
			m.put("role", request.getParameter("role"));
		}
		
		try {
			empService.ModifyEmployee(m);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		
	}


}
