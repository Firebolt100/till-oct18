package com.flp.ems.dao;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import com.flp.ems.domain.Employee;

public class EmployeeDaoImplForDB implements IemployeeDao {

	
	@Override
	public void AddEmployee(Employee employee) throws FileNotFoundException, SQLException, IOException{
		
		
		Properties props = new Properties();
		FileInputStream fln = new FileInputStream("dbDetails.properties");
		props.load(fln);
		String driver = props.getProperty("jdbc.driver");
		String url = props.getProperty("jdbc.url");
		Connection dbConnection ;
		dbConnection = DriverManager.getConnection(url);
		System.out.println("Connection to DB successful ? "+ (dbConnection != null));
		
		Statement st=null;
		String createtable = props.getProperty("jdbc.query.createtable");
		/*int rows; 
		rows=  st.executeUpdate(createtable);*/
		
		String insertQuery = props.getProperty("jdbc.query.insert");
		try(PreparedStatement insertStatement = dbConnection.prepareStatement(insertQuery)){
			
			insertStatement.setString(1, employee.getName());
			insertStatement.setString(2, employee.getKinId());
			insertStatement.setString(3, employee.getEmailId());
			insertStatement.setString(4, employee.getPhoneNo());
			insertStatement.setDate(5, new Date (employee.getDob().getTime() ));
			insertStatement.setDate(6, new Date (employee.getDoj().getTime() ));
			insertStatement.setString(7, employee.getAddress());
			insertStatement.setInt(8, employee.getDeptId());
			insertStatement.setInt(9, employee.getProjectId());
			insertStatement.setInt(10, employee.getRoleId());
			
			int rowsInserted = insertStatement.executeUpdate();
		}

	

	}
	
	public int getCount() throws SQLException{
		
		Connection dbConnection ;
		dbConnection = DriverManager.getConnection("jdbc:mysql://localhost:3306/test");
		System.out.println("Connection successful ? "+ (dbConnection != null));
		
		Statement selectStatement= dbConnection.createStatement();
		String selectQuery = "select * from employee";
		ResultSet result;
		result = selectStatement.executeQuery(selectQuery);
		
		int count=0;
		
		while(result.next()){
				count++;
			}
		
		dbConnection.close();
		selectStatement.close();
		
		return count;
		
	}

	@Override
	public void ModifyEmployee(Employee employee) throws SQLException, IOException {
		

		Connection dbConnection ;
		dbConnection = DriverManager.getConnection("jdbc:mysql://localhost:3306/test");
		System.out.println("Connection successful ? "+ (dbConnection != null));
					
		String modify = "select * from employee where kinId = ?";
		PreparedStatement modifyStatement = dbConnection.prepareStatement(modify,ResultSet.TYPE_FORWARD_ONLY,ResultSet.CONCUR_UPDATABLE);
		modifyStatement.setString(1, employee.getKinId());
		ResultSet result=null;
		result = modifyStatement.executeQuery();
		result.next();
		
		try{
			if(employee.getName()!=null)
				result.updateString(2, employee.getName());
			//result.updateString(3, employee.getKinId());
			//result.updateString(4, employee.getEmailId());
			if(employee.getPhoneNo()!=null)
				result.updateString(5, employee.getPhoneNo());
			if(employee.getDob()!=null)
				result.updateDate(6, new Date (employee.getDob().getTime() ));
			if(employee.getDoj()!=null)
			result.updateDate(7, new Date (employee.getDoj().getTime() ));
			if(employee.getAddress()!=null)
			result.updateString(8, employee.getAddress());
			if(employee.getDeptId()!=0)
			result.updateInt(9, employee.getDeptId());
			if(employee.getProjectId()!=0)
			result.updateInt(10, employee.getProjectId());
			if(employee.getRoleId()!=0)
			result.updateInt(11, employee.getRoleId());
			
			result.updateRow();
			
			
		}finally
			{
			dbConnection.close();
			modifyStatement.close();
			}

	}

	@Override
	public boolean RemoveEmployee(Employee employee) throws SQLException {
		
		Connection dbConnection ;
		dbConnection = DriverManager.getConnection("jdbc:mysql://localhost:3306/test");
		System.out.println("Connection successful ? "+ (dbConnection != null));
		
		//Statement removeStatement= dbConnection.createStatement();
		String removed = "delete from employee where kinId = ?";
		PreparedStatement removeStatement = dbConnection.prepareStatement(removed);
		removeStatement.setString(1, employee.getKinId());
		int row = removeStatement.executeUpdate();
		
		dbConnection.close();
		removeStatement.close();
		
		if(row ==1)
		  return true;
		else
			return false;
	}

	@Override
	public Employee SearchEmployee(Employee employee) throws SQLException {
		

		Connection dbConnection ;
		dbConnection = DriverManager.getConnection("jdbc:mysql://localhost:3306/test");
		System.out.println("Connection successful ? "+ (dbConnection != null));
		
		//Statement removeStatement= dbConnection.createStatement();
		String show = "select * from employee where KinId = ? or Name = ? or EmailId=?";
		PreparedStatement selectStatement = dbConnection.prepareStatement(show);
		
		/*if(employee.getKinId().equals(null))
			selectStatement.setString(1, "0");
		else*/
		System.out.println("KINID passed (DAO) "+ employee.getKinId());
			selectStatement.setString(1, employee.getKinId());
		
		/*if(employee.getName().equals(null))
			selectStatement.setString(2, "0");
		else*/
			selectStatement.setString(2, employee.getName());
		
		/*if(employee.getEmailId().equals(null))
			selectStatement.setString(3, "0");
		else*/
			selectStatement.setString(3, employee.getEmailId());
		
		ResultSet result;
		result = selectStatement.executeQuery();
		
		Employee e=new Employee();
		result.next();
		e.setName(result.getString("Name"));
		e.setKinId(result.getString("KinId"));
		e.setEmailId(result.getString("EmailId"));
		e.setPhoneNo(result.getString("PhoneNo"));
		e.setDob(result.getDate("Dob"));
		e.setDoj(result.getDate("DoJoining"));
		e.setAddress(result.getString("Address"));
		e.setDeptId(result.getInt("DeptId"));
		e.setProjectId(result.getInt("ProjectId"));
		e.setRoleId(result.getInt("RolesId"));
		
		dbConnection.close();
		selectStatement.close();
		
		return e;
	}

	@Override
	public List<Employee> getAllEmployee() throws SQLException {
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		Connection dbConnection ;
		dbConnection = DriverManager.getConnection("jdbc:mysql://localhost:3306/test");
		System.out.println("Connection successful ? "+ (dbConnection != null));
		
		Statement selectStatement= dbConnection.createStatement();
		String selectQuery = "select * from employee";
		ResultSet result;
		result = selectStatement.executeQuery(selectQuery);
		
		List<Employee> list = new ArrayList<Employee>();
				
		while(result.next()){
			Employee e = new Employee();
			e.setName(result.getString(2));
			e.setKinId(result.getString(3));
			e.setEmailId(result.getString(4));
			e.setDeptId(result.getInt(9));
			e.setProjectId(result.getInt(10));
			e.setRoleId(result.getInt(11));
			list.add(e);
			
			//System.out.println(e);
			
			}
		dbConnection.close();
		selectStatement.close();
		
		return list;
	}

	
}
