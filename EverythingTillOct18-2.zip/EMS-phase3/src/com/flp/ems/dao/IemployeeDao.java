package com.flp.ems.dao;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import com.flp.ems.domain.Employee;

public interface IemployeeDao {

	public void AddEmployee(Employee employee) throws FileNotFoundException, SQLException, IOException;
	public void ModifyEmployee(Employee employee) throws FileNotFoundException, SQLException, IOException;
	public boolean RemoveEmployee(Employee employee) throws SQLException;
	public Employee SearchEmployee(Employee employee) throws SQLException;
	public List<Employee> getAllEmployee() throws SQLException;
}
