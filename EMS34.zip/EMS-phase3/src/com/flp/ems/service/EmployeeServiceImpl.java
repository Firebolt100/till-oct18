package com.flp.ems.service;


import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;

import com.flp.ems.dao.EmployeeDaoImplForDB;
import com.flp.ems.dao.EmployeeDaoImplForList;
import com.flp.ems.domain.Employee;

public class EmployeeServiceImpl implements IEmployeeService{
	
	//to remove this line
	EmployeeDaoImplForList empdao = new EmployeeDaoImplForList();
	
	EmployeeDaoImplForDB empdaoDB = new EmployeeDaoImplForDB();
	
	//Add Employee
	public void AddEmployee(HashMap<String , String > h) throws FileNotFoundException, SQLException, IOException{
		
		Employee employee = new Employee();
		
		//to convert the DATE from string to Date format
		DateFormat df = new SimpleDateFormat("dd/mm/yyyy");
		Date d1=null,d2=null ;
		try {
			 d1= df.parse(h.get("dob"));
		} catch (ParseException e) {
	    
			e.printStackTrace();
		}
		try {
			 d2= df.parse(h.get("doj"));
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		int deptId= Integer.parseInt(h.get("deptId"));
		int projectId= Integer.parseInt(h.get("projectId"));
		int roleId= Integer.parseInt(h.get("roleId"));
		
		int count =empdaoDB.getCount();
		int k=count+1;
		String kinId=""+k+"_fs";
		h.put("kinId",kinId);
		String emailId =kinId+"@barclays.com";
		
		employee.setName(h.get("name"));
		employee.setPhoneNo(h.get("phoneNo"));
		employee.setAddress(h.get("address"));
		employee.setDob(d1);
		employee.setDoj(d2);
		employee.setDeptId(deptId);
		employee.setProjectId(projectId);
		employee.setRoleId(roleId);
		employee.setKinId(kinId);
		employee.setEmailId(emailId);
		
		//empdao.AddEmployee(employee);
		empdaoDB.AddEmployee(employee);
		
	}
	
	public void ModifyEmployee(HashMap<String , String > h) throws SQLException, IOException{
		
		Employee emp = new Employee();
		
		emp.setKinId(h.get("kinId"));
		
		//to convert the DATE from string to Date format
		DateFormat df = new SimpleDateFormat("dd/mm/yyyy");
		Date d1=null,d2=null ;
		
		try {
			if(h.containsKey("dob"))
			 d1= df.parse(h.get("dob"));
			else
				emp.setDob(null);
		} catch (ParseException e) {
	    			e.printStackTrace();
		  }
		
		try {
			if(h.containsKey("doj"))
			   d2= df.parse(h.get("doj"));
			else
				emp.setDoj(null);
		} catch (ParseException e) {
			e.printStackTrace();
		  }
		
		
		if(h.containsKey("name")){
			emp.setName(h.get("name"));
		}
		else
			emp.setName(null);
		
		if(h.containsKey("phoneNo")){
			emp.setPhoneNo(h.get("phoneNo") );
		}
		else
			emp.setPhoneNo(null);
		
		if(d1!=null){
			emp.setDob(d1) ;
		}
		
		if(d2!=null){
			emp.setDoj(d2);
		}
		if(h.containsKey("address")){
			emp.setAddress(h.get("address"));
		}
		else
			emp.setAddress(null);
		
		empdaoDB.ModifyEmployee(emp);
		
	}
	public boolean RemoveEmployee(HashMap<String , String > h) throws SQLException{
		
		Employee e = new Employee();
		e.setKinId(h.get("kinId"));
		e.setAddress(null);
		e.setDeptId(0);
		e.setDob(null);
		e.setDoj(null);
		e.setEmailId(null);
		e.setName(null);
		e.setPhoneNo(null);
		e.setProjectId(0);
		e.setRoleId(0);
		System.out.println("in serrvice of delete");
		boolean r = empdaoDB.RemoveEmployee(e) ;
		System.out.println("Back in serrvice of delete");
		return r;
		
	}
	public HashMap<String , String> SearchEmployee(HashMap<String , String > h) throws SQLException{
		Employee e = new Employee();
		Employee e2= null;
		HashMap<String,String> returning =new HashMap<String,String>();
		
		//if(!h.get("kinId").equals("0"))
			e.setKinId(h.get("kinId"));
		//else
			//e.setKinId(null);
		
		//if(!h.get("name").equals("0"))
			e.setName(h.get("name"));
		//else
		//	e.setName(null);
		
		//if(!h.get("emailId").equals("0"))
			e.setEmailId(h.get("emailId"));
		//else
		//	e.setEmailId(null);
		
		e2 = empdaoDB.SearchEmployee(e);
		String deptId = String.valueOf(e2.getDeptId());
		String projectId = String.valueOf( e2.getProjectId());
		String roleId = String.valueOf(e2.getRoleId());
						
						
		returning.put("name", e2.getName());
		returning.put("kinId", e2.getKinId());
		returning.put("emailId", e2.getEmailId());
		returning.put("phoneNo", e2.getPhoneNo());
		returning.put("deptId",deptId );
		returning.put("projectId",projectId);
		returning.put("roleId", roleId);
		
		return returning;
	}
	
	public HashMap<String,String>[] getAllEmployee() throws SQLException{
		
		List<Employee> l = empdaoDB.getAllEmployee();
		
		System.out.println("output from DAO DB");
		for(Employee temp : l)
			System.out.println(temp);
		
		HashMap<String , String> row[] = new HashMap[l.size()];
		
		int i=0;

		//System.out.println("in service");
		while(i<l.size()){
			//System.out.println("Putting to hashmap");
			String di="" +l.get(i).getDeptId();
			String pi ="" +l.get(i).getProjectId();
			String ri =	"" +	l.get(i).getRoleId();
			
			row[i]=new HashMap<String , String>();
			row[i].put("kinId",l.get(i).getKinId());
			row[i].put("name",l.get(i).getName());
			row[i].put("emailId",l.get(i).getEmailId());
			row[i].put("deptId",di);
			row[i].put("projectId",pi);
			row[i].put("roleId", ri);
			//System.out.println(l.get(i));
			
			i++;
					
		}
		
		System.out.println("passing to view");
		for(HashMap<String,String> temp : row){
			System.out.println(row.toString());
		}
		
		return row;
	}

}
