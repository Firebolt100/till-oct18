package com.flp.ems.view;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.HashMap;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.ems.service.EmployeeServiceImpl;

/**
 * Servlet implementation class S_getAllEmployees
 */
@WebServlet("/getAllEmployees")
public class S_getAllEmployees extends HttpServlet {
	private static final long serialVersionUID = 1L;
	EmployeeServiceImpl empService = new EmployeeServiceImpl();   

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		
		HashMap<String,String>[] h = null;
		try {
			h = empService.getAllEmployee();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		PrintWriter out= response.getWriter();
		//out.println(h.toString());
		out.println("<html><body><table>");
		out.println("<h3> No of Employees  : "+ h.length +"</h3>");
		out.println("<tr> <th> KinID </th> <th>  Name </th> <th>EmailID  </th> <th>   DeptID </th> <th> ProjectID </th> <th> RoleID </th> </tr> <br>");
		
		for (HashMap<String, String> hashMap : h) {
			//System.out.println("in loop");
			out.println("<tr><td>"+hashMap.get("kinId")+"</td> <td>"+ hashMap.get("name")+"</td> <td>"+ hashMap.get("emailId")+"</td> <td>"+ hashMap.get("deptId")+"</td> <td>"+ hashMap.get("projectId")+"</td> <td>"+hashMap.get("roleId")+"</td></tr><br>");
		}	
		
		out.println("<br>");
		
		
		out.println("</table></body></html>");
	}

	

}
