package com.flp.ems.view;

import java.io.IOException;
import java.sql.SQLException;
import java.util.HashMap;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.ems.service.EmployeeServiceImpl;


@WebServlet("/deleteEmployee")
public class S_deleteEmployee extends HttpServlet {
	private static final long serialVersionUID = 1L;
	EmployeeServiceImpl empService = new EmployeeServiceImpl();
	
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String kinId =request.getParameter("kinId");
		HashMap <String,String> h= new HashMap<String,String>();
		h.put("kinId", kinId);
		try {
			boolean r= empService.RemoveEmployee(h);
			if(r)
				System.out.println("<h3>Employee Deleted</h3>");
			else
				System.out.println("<h3>Employee Could NOT be Deleted</h3>");
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		
		
		
		
	}

}
