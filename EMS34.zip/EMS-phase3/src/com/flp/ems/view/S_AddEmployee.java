package com.flp.ems.view;

import java.io.IOException;
import java.sql.SQLException;
import java.util.HashMap;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.ems.service.EmployeeServiceImpl;


@WebServlet("/addEmployee")
public class S_AddEmployee extends HttpServlet {
	private static final long serialVersionUID = 1L;

    // Default constructor. 
    public S_AddEmployee() {
        
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		EmployeeServiceImpl empService = new EmployeeServiceImpl();
		HashMap <String , String > employeedetails = new HashMap <String , String >();

		String name =request.getParameter("name");
		String phoneNo=request.getParameter("phoneNo");
		String address =request.getParameter("address");
		String dob =request.getParameter("dob");
		String doj =request.getParameter("doj");
		String dept =request.getParameter("department");
		String project =request.getParameter("project");
		String role =request.getParameter("role");
		
		employeedetails.put("name", name);
		employeedetails.put("phoneNo", phoneNo);
		employeedetails.put("address", address);
		employeedetails.put("dob", dob);
		employeedetails.put("doj", doj);
		employeedetails.put("deptId", dept);
		employeedetails.put("projectId", project);
		employeedetails.put("roleId", role);
		
		try {
			empService.AddEmployee(employeedetails);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
	}

}
